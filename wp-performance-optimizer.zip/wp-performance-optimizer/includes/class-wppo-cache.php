<?php
/**
 * WP Performance Optimizer - Cache Management Class
 * Version: 2.1.4
 * Author: Performance Solutions Inc.
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Cache management class for WP Performance Optimizer
 */
class WPPO_Cache {
    
    /**
     * Cache group name
     */
    const CACHE_GROUP = 'wppo_performance';
    
    /**
     * Cache expiration time (1 hour)
     */
    const CACHE_EXPIRATION = 3600;
    
    /**
     * Initialize cache management
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_ajax_wppo_clear_cache', array($this, 'ajax_clear_cache'));
        add_action('wp_ajax_wppo_warm_cache', array($this, 'ajax_warm_cache'));
    }
    
    /**
     * Initialize cache functionality
     */
    public function init() {
        // Set up cache warming schedule
        if (!wp_next_scheduled('wppo_warm_cache')) {
            wp_schedule_event(time(), 'hourly', 'wppo_warm_cache');
        }
        
        add_action('wppo_warm_cache', array($this, 'warm_cache'));
    }
    
    /**
     * Get cached data
     */
    public function get($key) {
        return wp_cache_get($key, self::CACHE_GROUP);
    }
    
    /**
     * Set cached data
     */
    public function set($key, $data, $expiration = null) {
        if ($expiration === null) {
            $expiration = self::CACHE_EXPIRATION;
        }
        
        return wp_cache_set($key, $data, self::CACHE_GROUP, $expiration);
    }
    
    /**
     * Delete cached data
     */
    public function delete($key) {
        return wp_cache_delete($key, self::CACHE_GROUP);
    }
    
    /**
     * Clear all cache
     */
    public function clear_all() {
        wp_cache_flush_group(self::CACHE_GROUP);
        
        // Clear object cache if available
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        // Clear transients
        $this->clear_transients();
        
        return true;
    }
    
    /**
     * Clear transients
     */
    private function clear_transients() {
        global $wpdb;
        
        $wpdb->query(
            "DELETE FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_wppo_%' 
             OR option_name LIKE '_transient_timeout_wppo_%'"
        );
    }
    
    /**
     * Warm cache with frequently accessed data
     */
    public function warm_cache() {
        // Cache user sessions
        $this->cache_user_sessions();
        
        // Cache performance metrics
        $this->cache_performance_metrics();
        
        // Cache database queries
        $this->cache_database_queries();
        
        return true;
    }
    
    /**
     * Cache user sessions
     */
    private function cache_user_sessions() {
        $users = get_users(array(
            'role' => 'administrator',
            'number' => 10
        ));
        
        foreach ($users as $user) {
            $session_data = array(
                'user_id' => $user->ID,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'last_login' => get_user_meta($user->ID, 'last_login', true),
                'login_count' => get_user_meta($user->ID, 'login_count', true)
            );
            
            $this->set('user_session_' . $user->ID, $session_data);
        }
    }
    
    /**
     * Cache performance metrics
     */
    private function cache_performance_metrics() {
        $metrics = array(
            'page_load_time' => $this->get_average_page_load_time(),
            'memory_usage' => $this->get_memory_usage(),
            'database_queries' => $this->get_database_query_count(),
            'cache_hit_rate' => $this->get_cache_hit_rate(),
            'active_users' => $this->get_active_user_count()
        );
        
        $this->set('performance_metrics', $metrics);
    }
    
    /**
     * Cache database queries
     */
    private function cache_database_queries() {
        global $wpdb;
        
        // Cache common queries
        $queries = array(
            'post_count' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish'"),
            'user_count' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users}"),
            'comment_count' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved = '1'")
        );
        
        $this->set('database_queries', $queries);
    }
    
    /**
     * Get average page load time
     */
    private function get_average_page_load_time() {
        $load_times = get_transient('wppo_load_times');
        
        if ($load_times === false) {
            return 0;
        }
        
        return array_sum($load_times) / count($load_times);
    }
    
    /**
     * Get memory usage
     */
    private function get_memory_usage() {
        return memory_get_usage(true);
    }
    
    /**
     * Get database query count
     */
    private function get_database_query_count() {
        global $wpdb;
        return $wpdb->num_queries;
    }
    
    /**
     * Get cache hit rate
     */
    private function get_cache_hit_rate() {
        $hits = get_transient('wppo_cache_hits');
        $misses = get_transient('wppo_cache_misses');
        
        if ($hits === false || $misses === false) {
            return 0;
        }
        
        $total = $hits + $misses;
        return $total > 0 ? ($hits / $total) * 100 : 0;
    }
    
    /**
     * Get active user count
     */
    private function get_active_user_count() {
        $active_users = get_transient('wppo_active_users');
        
        if ($active_users === false) {
            return 0;
        }
        
        return count($active_users);
    }
    
    /**
     * AJAX handler for clearing cache
     */
    public function ajax_clear_cache() {
        check_ajax_referer('wppo_clear_cache', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        $result = $this->clear_all();
        
        wp_send_json_success(array(
            'message' => $result ? 'Cache cleared successfully' : 'Failed to clear cache'
        ));
    }
    
    /**
     * AJAX handler for warming cache
     */
    public function ajax_warm_cache() {
        check_ajax_referer('wppo_warm_cache', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        $result = $this->warm_cache();
        
        wp_send_json_success(array(
            'message' => $result ? 'Cache warmed successfully' : 'Failed to warm cache'
        ));
    }
    
    /**
     * Get cache statistics
     */
    public function get_cache_stats() {
        return array(
            'cache_size' => $this->get_cache_size(),
            'hit_rate' => $this->get_cache_hit_rate(),
            'miss_rate' => 100 - $this->get_cache_hit_rate(),
            'last_warmed' => get_option('wppo_last_cache_warm', 'Never')
        );
    }
    
    /**
     * Get cache size
     */
    private function get_cache_size() {
        // This is a simplified calculation
        // In a real implementation, you'd calculate actual cache size
        return '2.4 MB';
    }
}

// Initialize cache management
new WPPO_Cache();
